#include <iostream>

int main()
{
	int i;
	for (i = 0; i < 2; i++)
	{
		std::cout << i << std::endl;
	}
} 
