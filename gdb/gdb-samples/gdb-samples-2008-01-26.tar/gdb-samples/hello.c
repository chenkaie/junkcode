#include <stdio.h>

static char *my_str = "Hello World!";
int main()
{
	puts(my_str);
	return 0;
}
