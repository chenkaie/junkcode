#include <stdio.h>

int subtract(int a, int b)
{
	   return (a - b);
}

int main()
{
	printf("out = %d\n", subtract(3, 2));
	return 0;
}	
