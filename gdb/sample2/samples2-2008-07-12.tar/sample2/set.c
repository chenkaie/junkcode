int main()
{
	int a, b, c = 0;
	c = a + b;
	return 0;
}
