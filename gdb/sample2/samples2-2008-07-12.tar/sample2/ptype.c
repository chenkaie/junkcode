struct Rect {
	int x;
	int y;
};

int main()
{
	struct Rect rect = { -10, 20 };
	return 0;
}
