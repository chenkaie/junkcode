#include <stdio.h>

main()
{
   printf("Hello, %s!\n", OS);
}
