#include <stdio.h>
#include <math.h>

main()
{
   printf("%f\n", log(1024));
}
