#define square(x) (x * x)

int main(void){
	int i=0;
	printf("%d\n",square(++i));
}
