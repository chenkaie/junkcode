
int main(void){
	mkfifo("fifo",0660);
}
