#include <stdio.h>

int main(void){
	long long int i=0l;
}
