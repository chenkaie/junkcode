
inline void test(void){
	printf("test\n");
}

//inline test
int main(void){
	test();
}
