
int main(void){
	printf("%s %s\n",__FILE__,__FUNCTION__);
}
