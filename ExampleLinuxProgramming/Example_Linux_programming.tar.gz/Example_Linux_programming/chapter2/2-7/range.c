
void test(){
	int var;
	switch(var){
		case 0 ... 10:
			break;
		case 11 ... 20:
			break;
	}
}
