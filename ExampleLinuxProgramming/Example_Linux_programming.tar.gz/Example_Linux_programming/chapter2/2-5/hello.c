#include "hello.h"

int main(void){
	printf("hello\n");
}
