
int main(void){
	test();
}
