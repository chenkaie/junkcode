
void test(){
	printf("this is a library test\n");
}
