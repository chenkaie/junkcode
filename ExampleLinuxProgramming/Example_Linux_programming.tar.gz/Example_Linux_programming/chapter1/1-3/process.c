
int main(void){
	printf("hello world from process ID %d\n",getpid());
}
